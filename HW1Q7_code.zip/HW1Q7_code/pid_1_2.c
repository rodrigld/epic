/**
 *
 * Operating System Concepts
 * Copyright John Wiley & Sons, 2013.
 */

#include "pid.h"
#include <pthread.h>
#include <stdio.h>

/**
 * Allocates the pid map.
 */
int allocate_map(void) 
{

	/* write your code here */

}

/**
 * Allocates a pid
 */
int allocate_pid(void)
{

	/* write your code here */

}

/**
 * Releases a pid
 */
void release_pid(int pid)
{
	
	/* write your code here */

}
