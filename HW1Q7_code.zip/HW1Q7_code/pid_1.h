#define PID_MIN  	300
#define PID_MAX 	5000

int pid_map[PID_MAX+1];

int last;	// last pid in use
